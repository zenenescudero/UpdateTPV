
-- crear base de datos
--Modern_Spanish_CI_AS

use [DB_Paraiso];

go

CREATE TABLE [Sucursales](
		[Id] int NOT NULL PRIMARY KEY,
		[Descripcion] [varchar](250) NOT NULL,
		[Direccion] [varchar](250) NULL,
		[Colonia] [varchar](250) NULL,
		[Ciudad] [varchar](250) NULL,
		[Estado] [varchar](250) NULL,
		[Municipio] [varchar](250) NULL,
		[Pais] [varchar](250) NULL,
		[Lada] [varchar](10) NULL,
		[Telefono1] [varchar](20) NULL,
		[Telefono2] [varchar](20) NULL,
		[Fax] [varchar](20) NULL,
		[CP] [varchar](10) NULL,
		[Activo] int NOT NULL DEFAULT 1,
		[SerieFactura] varchar(10) null,
		[FolioFactura] int default 1,
		[SeriePago] varchar(10) null,
		[FolioPago] int default 1,
		[SerieCredito] varchar(10) null,
		[FolioCredito] int default 1)

go

CREATE TABLE Usuarios(
    [Id] int NOT NULL PRIMARY KEY,
	[Login] [varchar](15) NOT NULL unique,
	[Nombre] [varchar](250) NOT NULL,
	[Password] [varchar](max) NULL,
	[Activo] int NOT NULL DEFAULT 1,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

CREATE TABLE OpcionesMenu(
	[Id] int NOT NULL PRIMARY KEY,
	[Opcion] varchar(10) NOT null,
	[Descripcion] varchar(60) NOT null,
	Seccion varchar(10) null
)

go

CREATE TABLE UsuarioOpcionesMenu(
	 [Id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	 [UsuarioId] int not null,
	 [OpcionId] int NOT null,
	 [Crear] int not null default 0,
	 [Editar] int not null default 0,
	 [Eliminar] int not null default 0,
	 [Consultar] int not null default 1,
	 FOREIGN KEY ([UsuarioId]) REFERENCES Usuarios([Id]),
	 FOREIGN KEY ([OpcionId]) REFERENCES OpcionesMenu([Id])
)

GO

CREATE TABLE UsuariosSucursal(
      [Id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
      [SucursalId] int not null,
      [UsuarioId] int not null,
	 FOREIGN KEY ([UsuarioId]) REFERENCES Usuarios([Id]),
	 FOREIGN KEY ([SucursalId]) REFERENCES [Sucursales]([Id]),
)

go

CREATE TABLE Clientes(
	[Id] [bigint] NOT NULL PRIMARY key,
	[Nombre] [varchar](200) NOT NULL,
	[Direccion] [varchar](200) NULL,
	[Colonia] [varchar](100) NULL,
	[Ciudad] [varchar](100) NULL,
	[Estado] [varchar](50) NULL,
	[CP] [varchar](8) NULL,
	[RFC] [varchar](15) NULL,
	[RegimenFiscal] varchar(5) null,
	[RegimenFiscalDescripcion] varchar(250) null,
	[UsoCFDI] varchar(5) null,
	[UsoCFDIDesc] varchar(250) null,
	[LADA] [varchar](10) NULL,
	[Telefono1] [varchar](20) NULL,
	[Telefono2] [varchar](20) NULL,
	[Limite] [decimal](15,2) NULL,	
	[Observaciones] [text] NULL,
	[Email] [varchar](200) NULL,
	[Email2] [varchar](200) NULL,
	[Pais] [varchar](100) NULL,
	[FormaPago] [varchar](5) NULL,
	[FormaPagoDesc] [varchar](250) NULL,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1,
	[Activo] [int] NULL
	)

go

CREATE TABLE CAT_MARCAS(
	[Id] bigint NOT NULL PRIMARY KEY,
	[Marca] varchar(10) NOT null,
	[Descripcion] varchar(250) null,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1,
	[Activo] [int] NULL
)


go
CREATE TABLE CAT_SECCIONES(
    [Id] bigint NOT NULL PRIMARY KEY,
	[Seccion] varchar(10) NOT null,
	[Descripcion] varchar(250) null,	
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1,
	[Activo] [int] NULL
)
go

CREATE TABLE Proveedores(
	[Id] bigint NOT NULL PRIMARY KEY,
	[Proveedor] [varchar](5) NOT NULL unique,
	[Nombre] [varchar](250) NOT NULL,
	[Beneficiario] [varchar](250) NULL,
	[DIRECCION] [varchar](250) NULL,
	[Colonia] [varchar](30) NULL,
	[Ciudad] [varchar](30) NULL,
	[Estado] [varchar](30) NULL,
	[CP] [varchar](10) NULL,
	[PAIS] [varchar](30) NULL,
	[RFC] [varchar](15) NULL,
	[LADA] [varchar](10) NULL,
	[TEL1] [varchar](20) NULL,
	[TEL2] [varchar](20) NULL,
	[Fax] [int] NULL,
	[EMAIL] [varchar](250) NULL,
	[Observaciones] [text] NULL,
	[Contacto1] [varchar](250) NULL,
	[Contacto2] [varchar](250) NULL,
	[Activo] [int] NOT NULL DEFAULT 1,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1)
go

CREATE TABLE [CAT_CLAVEPRODSERV](
	[C_CLAVEPRODSERV] [varchar](20) NULL,
	[DESCRIPCION] [varchar](200) NULL)

go

CREATE TABLE [CAT_CLAVEUNIDAD](
	[C_CLAVEUNIDAD] [varchar](20) NULL,
	[NOMBRE] [varchar](200) NULL
)

go

CREATE TABLE [CAT_FORMAPAGO](
	[C_FORMAPAGO] [varchar](10) NULL,
	[DESCRIPCION] [varchar](200) NULL
)

go

CREATE TABLE [CAT_USOCFDI](
	[C_USOCFDI] [varchar](10) NULL,
	[DESCRIPCION] [varchar](200) NULL,
	RegimenFiscal varchar(max) null,
	Fisica varchar(5) null,
	Moral varchar(5) null
)

go
CREATE TABLE [CAT_METODOPAGO](
	[C_METODOPAGO] [varchar](10) NULL,
	[DESCRIPCION] [varchar](200) NULL
)


go

CREATE TABLE CAT_UNIDADES(
	[Id] bigint NOT NULL PRIMARY KEY,
	[Unidad] varchar(10) null,
	[Nombre] varchar(50) null,
	[Principal] int not null default 0,
	[Activo] [int] NOT NULL DEFAULT 1,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

CREATE TABLE Articulos(
	[Id] bigint NOT NULL PRIMARY KEY,
	[ARTICULO] [varchar](15) NOT NULL unique,
	[Descripcion] [varchar](2000) NOT NULL,
	[ProveedorId] [bigint] NULL,
	[SeccionId] [bigint] NULL,
	[MarcaId] [bigint] NULL,	
	[Activo] [int] NOT NULL DEFAULT 1,
	[Unidad] [varchar](20) NULL,	
	[BARRAS] [varchar](20) null,
	[CLAVEPRODSERV] [varchar](10) NULL,
	[CLAVEPRODSERV_Desc] [varchar](200) NULL,
	[CLAVEUNIDAD] [varchar](10) NULL,
	[CLAVEUNIDAD_Desc] [varchar](200) NULL,
	[PrecioCompra] [decimal](15,4) not null,
	[Margen] [decimal](15,4) NULL,
	[Exento] int default 0,
	[PrecioUnitario] decimal(15,4) not null,
	[ImpuestoIva] [decimal](6, 4) NULL,
	[ImpuestoIeps] [decimal](6, 4) NULL,	
	[ImpuestoIvaVal] [decimal](15, 4) NULL,
	[ImpuestoIepsVal] [decimal](15, 4) NULL,
	[PrecioVenta] decimal(15,4) not null,
	[Margen3] decimal(15,4) not null default 0,
	[Precio3] decimal(15,4) not null default 0,
	[Margen6] decimal(15,4) not null default 0,
	[Precio6] decimal(15,4) not null default 0,
	[Margen9] decimal(15,4) not null default 0,
	[Precio9] decimal(15,4) not null default 0,
	[Margen12] decimal(15,4) not null default 0,
	[Precio12] decimal(15,4) not null default 0,
	[Margen18] decimal(15,4) not null default 0,
	[Precio18] decimal(15,4) not null default 0,	
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
	)

go

CREATE TABLE CAT_TIPOCADENAPAGO(
	[Id] int NOT NULL PRIMARY KEY,
	[C_TIPOCADENA] varchar(60) null,
	[DESCRIPCION] varchar(200) null,
	[Activo] int not null default 1
)


GO

CREATE TABLE CAT_REGIMENFISCAL(
	[C_REGIMENFISCAL] varchar(10) null,
	[DESCRIPCION] varchar(250) null,
	[Fisica] int,
	[Moral]  int
)

GO

CREATE TABLE CAT_TIPORELACION(
  [C_TIPORELACION] varchar(10) null,
  [DESCRIPCION] varchar(250) null
)
go
-- nuevas 15-02-2022
CREATE TABLE CAT_PAISES(
	[Id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[CLAVE] varchar(10) NOT null unique,
	[NOMBRE] varchar(250) null,
	Activo int not null default 1
)
go
CREATE TABLE CAT_ESTADO(
	[Id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[CLAVE] varchar(10) NOT null,
	[CLAVE_PAIS] varchar(10) NOT null,
	[NOMBRE] varchar(250) null,
	Activo int not null default 1
)
go
CREATE TABLE CAT_MUNICIPIO(
	[Id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[CLAVE] varchar(10) NOT null,
	[CLAVE_ESTADO] varchar(10) NOT null,
	[NOMBRE] varchar(250) null,
	Activo int not null default 1
)
go
CREATE TABLE Columnas(
	[Id] int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[Tabla] varchar(100) null,
	[Campo] varchar(100) null,
	[Descripcion] varchar(100) null,
	[Largo] int null,
	[Formato] varchar(20) null
)

go
create table CAT_CONCEPTOSINV(
	Id bigint not null PRIMARY key,
	Concepto varchar(10) not null unique,
	Tipo varchar(2) not null,
	Descripcion varchar(100) not null,
	Activo int not null default 1,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go
create table InventarioMovimientos(
	Id bigint not null PRIMARY key,
	IdTicket bigint NOT NULL,
	IdOrdenCompra bigint NOT NULL,
	ArticuloId bigint not null,
	Articulo varchar(15) null,
	SucursalId int not null,
	Tipo varchar(2) not null,
	ConceptoInvId bigint not null,
	FolioCompra varchar(50) null,
	Comentario varchar(200) null,
	Entrada decimal(15,4),
	Salida decimal(15,4),
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)
go

create table OrdenCompra(
	Id bigint not null PRIMARY key,
	SucursalId int not null,
	ProveedorId bigint not null,
	Serie varchar(5) null,
	Folio varchar(20) null,
	UUID varchar(50) null,
	FechaSolicitud datetime null,
	FechaEntrega datetime null,
	FechaRegistro datetime null,
	SubTotal decimal(15,2) not null,
	Impuestos decimal(15,2) not null,
	Descuento decimal(15,2) not null,
	Total decimal(15,2) not null,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

create table OrdenCompraDetalle(
	Id bigint not null PRIMARY key,
	IdOrdenCompra bigint not null,
	SucursalId int not null,
	Partida int not null,
	ClaveProdServ varchar(10) null,
	ClaveUnidad varchar(10) null,
	CodigoProveedor varchar(30) null,	
	Articulo varchar(15) not null,
	Descripcion varchar(1000) not null,
	ArticuloId bigint not null,
	ArticuloSis varchar(15) not null,
	DescripcionSis varchar(1000) not null,	
	Cantidad decimal(10,3) not null,	
	Unidad varchar(50) not null,
	ValorUnitario decimal(15,2) not null,
	Importe decimal(15,2) not null,
	Descuento decimal(15,2) not null,
	ObjetoImp varchar(5) null,
	Iva decimal(15,4) not null,
	IvaVal decimal(15,4) not null,
	Ieps decimal(15,2) not null,
	IepsVal decimal(15,2) not null,	
	TotalUnitario decimal(15,2) not null,
	Total decimal(15,2) not null,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Enviado int default 0,	
	[Version] bigint not null default 1
)

go


create table Tickets(
	Id bigint not null PRIMARY key,
	SucursalId int not null,
	ClienteId bigint null,
	Observaciones varchar(500) null,
	Fecha datetime null,
	Serie varchar(5) null,
	Folio int null,
	UUID varchar(50) null,
	Moneda varchar(5) null,
	TipoCambio decimal(15,6) null,
	Total decimal(15,2) null,
	FormaPago varchar(5) null,
	FormaPagoDesc varchar(50) null,
	UsoCFDI varchar(5) null,
	UsoCFDIDesc varchar(50) null,
	MetodoPago varchar(5) null,
	MetodoPagoDesc varchar(50) null,
	Banco varchar(50) null,
	Referencia varchar(50) null,
	Plazo int not null default 0,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Cancelado int default 0,
	Facturado int default 0,
	Enviado int default 0,	
	[Version] bigint not null default 1
)

go

create table TicketsDetalle(
	Id bigint not null PRIMARY key,
	IdTicket bigint not null,
	SucursalId int not null,
	Partida int not null,
	ClaveProdServ varchar(10) null,
	ClaveUnidad varchar(10) null,
	ArticuloId bigint not null,	
	Articulo varchar(15) not null,
	Descripcion varchar(1000) not null,
	Cantidad decimal(10,3) not null,	
	Unidad varchar(50) not null,
	ValorUnitario decimal(15,6) not null,
	Importe decimal(15,6) not null,
	Descuento decimal(15,6) not null,
	ObjetoImp varchar(5) null,
	BaseIva decimal(15,6) not null,
	Iva decimal(15,4) not null,
	IvaVal decimal(15,6) not null,
	BaseIeps decimal(15,6) not null,
	Ieps decimal(15,6) not null,
	IepsVal decimal(15,6) not null,	
	Total decimal(15,6) not null,	
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

create table ticketsCancelados(
	Id bigint not null PRIMARY key,
	Motivo varchar(5) null,
	MotivoDesc varchar(50) null,
	MotivoTexto varchar(100) null,
	IdTicket bigint not null,
	SucursalId int not null,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Enviado int default 0,
	[Version] bigint not null default 1

)

go

create table Facturas(
	Id bigint not null PRIMARY key,
	SucursalId int not null,
	ClienteId bigint not null,
	Historico int default 0,
	Version varchar(5) null,
	Serie varchar(5) null,
	Folio int null,
	UUID varchar(50) null,
	Fecha datetime null,
	FormaPago varchar(5) null,
	FormaPagoDesc varchar(50) null,
	NoCertificado varchar(20) null,
	CondicionesDePago varchar(100) null,
	Plazo int not null default 0,
	SubTotal decimal(15,2) null,
	Impuestos decimal(15,2) null,
	Descuento decimal(15,2) null,
	Moneda varchar(5) null,
	TipoCambio decimal(15,6) null,
	Total decimal(15,2) null,
	TipoDeComprobante varchar(5) null,	
	TipoDeComprobanteDesc varchar(100) null,
	MetodoPago varchar(10) null,
	MetodoPagoDesc varchar(100) null,
	LugarExpedicion varchar(5) null,
	InformacionGlobal_Periodicidad varchar(50) null,
	InformacionGlobal_PeriodicidadDesc varchar(50) null,
	InformacionGlobal_Mes varchar(50) null,
	InformacionGlobal_MesDesc varchar(50) null,
	Emisor_Rfc varchar(15) null,
	Emisor_RegimenFiscal varchar(5) null,
	Emisor_RegimenFiscalDesc varchar(250) null,
	Emisor_Nombre varchar(250) null,	
	Receptor_Rfc varchar(15) null,	
	Receptor_Nombre varchar(250) null,
	Direccion varchar(250) null,
	DomicilioFiscalReceptor varchar(10) null,
	RegimenFiscalReceptor varchar(10) null,
	RegimenFiscalReceptorDesc varchar(250) null,
	UsoCFDI varchar(10) null,
	UsoCFDIDesc varchar(100) null,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Cancelado int default 0,
	Enviado int default 0,
	EnviadoCliente int default 0,
	VersionRegistro bigint not null default 1) 

go

create table FacturasDetalle(
	Id bigint not null PRIMARY key,
	FacturaId bigint null,
	Serie varchar(5) null,
	Folio int null,
	IdTicket bigint null,
	SucursalId int null,
	Partida int not null,
	ClaveProdServ varchar(10) null,
	ClaveUnidad varchar(10) null,	
	Articulo varchar(15) not null,
	Descripcion varchar(1000) not null,
	Cantidad decimal(10,3) not null,	
	Unidad varchar(50) not null,
	ValorUnitario decimal(15,2) not null,
	Importe decimal(15,2) not null,
	Descuento decimal(15,2) not null,
	ObjetoImp varchar(5) null,
	BaseIva decimal(15,4) not null,
	Iva decimal(15,4) not null,
	IvaVal decimal(15,4) not null,
	BaseIeps decimal(15,4) not null,
	Ieps decimal(15,2) not null,
	IepsVal decimal(15,2) not null,
	Total decimal(15,2) not null,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

create table CfdiRelacionado(
	Id bigint not null PRIMARY key,
	UUIDRef varchar(50) null,
	TipoRelacion varchar(5) null,
	TipoRelacionDesc varchar(50) null,
	Serie varchar(5) null,
	Folio int null,
	UUID varchar(50) null,
	Fecha datetime null,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)
go

create table CfdiCancelados(
	Id bigint not null PRIMARY key,	
	Serie varchar(5) null,
	Folio int null,
	Tipo varchar(20) null,
	TipoDesc varchar(50) null,
	Tabla varchar(50) null,
	UUID varchar(50) null,	
	Fecha datetime null,
	Total decimal(15,2) not null default 0,
	SucursalId int not null,
	ClienteId bigint not null,
	Receptor_Rfc varchar(15) null,	
	Receptor_Nombre varchar(250) null,
	DomicilioFiscalReceptor varchar(10) null,
	RegimenFiscalReceptorDesc varchar(250) null,
	UsoCFDIDesc varchar(100) null,
	Motivo varchar(5) null,
	MotivoDesc varchar(50) null,	
	Folio_Sustitucion varchar(50) null,
	Codigo varchar(50) null,
	Mensaje varchar(100) null,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Enviado int default 0,
	Pendiente int default 0,	
	Version bigint not null default 1
)
go

create table ComplementoPago(
	Id bigint not null PRIMARY key,
	TicketId bigint not null,
	SucursalId int not null,
	ClienteId bigint not null,
	Historico int default 0,
	Version varchar(5) null,
	Serie varchar(5) null,
	Folio int null,	
	UUID varchar(50) null,
	Fecha datetime null,
	NoCertificado varchar(20) null,
	LugarExpedicion varchar(5) null,
	Emisor_Rfc varchar(15) null,
	Emisor_RegimenFiscal varchar(5) null,
	Emisor_RegimenFiscalDesc varchar(100) null,
	Emisor_Nombre varchar(250) null,	
	Receptor_Rfc varchar(15) null,	
	Receptor_RegimenFiscal varchar(5) null,
	Receptor_RegimenFiscalDesc varchar(100) null,
	Receptor_Nombre varchar(250) null,
	Direccion varchar(250) null,
	DomicilioFiscalReceptor varchar(10) null,

	TotalTrasladosBaseIVA16 decimal(15,2) null,
	TotalTrasladosImpuestoIVA16 decimal(15,2) null,

	TotalTrasladosBaseIVA8 decimal(15,2) null,
	TotalTrasladosImpuestoIVA8 decimal(15,2) null,

	TotalTrasladosBaseIVA0 decimal(15,2) null,
	TotalTrasladosImpuestoIVA0 decimal(15,2) null,

	TotalTrasladosBaseIVAExento decimal(15,2) null,

	MontoTotalPagos decimal(15,2) null,
	FechaPago datetime null,
	FormaPago varchar(5) null,
	FormaPagoDesc varchar(50) null,
	MonedaP varchar(5) null,
	TipoCambioP decimal(15,6) null,
	Monto decimal(15,2) null,
	NumOperacion varchar(80) null,
	RfcEmisorCtaOrd varchar(20) null,
	NomBancoOrdExt varchar(200) null,
	CtaOrdenante varchar(80) null,
	RfcEmisorCtaBen varchar(20) null,
	CtaBeneficiario varchar(80) null,
	TipoCadPago varchar(20) null,
	CertPago varchar(max) null,
	CadPago varchar(max) null,
	SelloPago varchar(max) null,

	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Cancelado int default 0,
	Enviado int default 0,
	Facturado int default 0,	
	VersionRegistro bigint not null default 1
)

go

create table DocRelPago(
	Id bigint not null PRIMARY key,
	TicketId bigint not null,
	Historico int default 0,
	[Partida] int null,
	Serie varchar(5) null,
	Folio int null,	
	IdDocumento varchar(50) null,
	SerieF varchar(5) null,
	FolioF int null,
	FolioPago bigint null,	
	MonedaDR varchar(5) null,
	EquivalenciaDR decimal(15,6) null,
	NumParcialidad int null,
	ImpSaldoAnt decimal(15,2) null,
	ImpPagado decimal(15,2) null,
	ImpSaldoInsoluto decimal(15,2) null,
	ObjetoImpDR varchar(5) null,
	ObjetoImpDRDesc varchar(100) null,
	Cancelado int default 0,		
	Facturado int default 0,

	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[VersionRegistro] bigint not null default 1
)

go

create table EstadoCuenta(
	Id bigint not null PRIMARY key,
	Historico int not null,
	SucursalId int null,
	TicketId bigint not null default 0,
	ConceptoCXC varchar(5) null,
	ConceptoCXCDesc varchar(50) null,
	Serie varchar(10) null,
	Folio int null,
	UUID varchar(50) null,
	ClienteId bigint not null,
	Moneda varchar(5) null,
	TipoCambio decimal(15,6) null,
	Fecha datetime null,
	FechaCancelacion datetime null,
	Plazo int null,
	SeriePadre varchar(10) null,
	FolioPadre int null,
	UUID_Padre varchar(50) null,
	EsPadre int null,
	Numero int not null default 1,
	Cargo decimal(15,2) null,
	Abono decimal(15,2) null,
	SubTotal decimal(15,2) null,
	Iva decimal(15,2) null,
	Ieps decimal(15,2) null,
	Total decimal(15,2) null,
	Saldo decimal(15,2) null,
	Observaciones varchar(100) null,
	FormaPago varchar(5) null,
	FormaPagoDesc varchar(50) null,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Cancelado int default 0,
	Enviado int default 0,	
	Version bigint not null default 1
)


go

create table NotasCredito(
	Id bigint not null PRIMARY key,
	TicketId bigint not null default 0,
	SucursalId int not null,
	ClienteId bigint not null,
	Historico int default 0,
	Version varchar(5) null,
	Serie varchar(5) null,
	Folio int null,
	UUID varchar(50) null,
	Fecha datetime null,
	FormaPago varchar(5) null,
	FormaPagoDesc varchar(50) null,
	NoCertificado varchar(20) null,
	SubTotal decimal(15,2) null,
	Descuento decimal(15,2) null,
	Moneda varchar(5) null,
	TipoCambio decimal(15,6) null,
	Total decimal(15,2) null,
	TipoDeComprobante varchar(5) null,	
	TipoDeComprobanteDesc varchar(100) null,
	MetodoPago varchar(10) null,
	MetodoPagoDesc varchar(100) null,
	LugarExpedicion varchar(5) null,
	Emisor_Rfc varchar(15) null,
	Emisor_RegimenFiscal varchar(5) null,
	Emisor_RegimenFiscalDesc varchar(100) null,
	Emisor_Nombre varchar(250) null,	
	Receptor_Rfc varchar(15) null,	
	Receptor_Nombre varchar(250) null,
	Direccion varchar(250) null,
	DomicilioFiscalReceptor varchar(10) null,
	RegimenFiscalReceptor varchar(10) null,
	RegimenFiscalReceptorDesc varchar(100) null,
	UsoCFDI varchar(10) null,
	UsoCFDIDesc varchar(100) null,
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Cancelado int default 0,
	Enviado int default 0,
	Facturado int default 0,
	VersionRegistro bigint not null default 1) 
go

create table NotasCreditoDetalle(
	Id bigint not null PRIMARY key,
	NotaCreditoId bigint not null default 0,
	Serie varchar(5) null,
	Folio int null,
	SucursalId int null,
	Partida int not null,
	ClaveProdServ varchar(10) null,
	ClaveUnidad varchar(10) null,	
	Articulo varchar(15) not null,
	Descripcion varchar(1000) not null,
	Cantidad decimal(10,3) not null,	
	Unidad varchar(50) not null,
	ValorUnitario decimal(15,2) not null,
	Importe decimal(15,2) not null,
	Descuento decimal(15,2) not null,
	ObjetoImp varchar(5) null,
	Iva decimal(15,4) not null,
	IvaVal decimal(15,4) not null,
	Ieps decimal(15,2) not null,
	IepsVal decimal(15,2) not null,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

create table ConfiguracionApp(
	Id int not null primary key,
	Parametro varchar(50) not null,
	Valor varchar(500) not null
)

go

create table Traspaso(
	Id bigint not null PRIMARY key,
	SucursalIdSalida int not null,
	SucursalIdEntrega int not null,
	FechaSalida datetime null,
	FechaEntrega datetime null,
	UsuarioSalida VARCHAR(50),
	UsuarioEntrega VARCHAR(50),
	Entregado int not null default 0,
	UsuarioId int null,
	QUIEN VARCHAR(50),
	CUANDO datetime null,
	EQUIPO varchar(50) null,
	Enviado int default 0,
	[Version] bigint not null default 1
)

go

create table TraspasoDetalle(
	Id bigint not null PRIMARY key,
	TraspasoId bigint not null,
	ArticuloId bigint not null,
	Articulo varchar(15) not null,
	Unidad varchar(50) not null,
	Descripcion varchar(1000) not null,
	Cantidad decimal(10,3) not null,	
	UsuarioId int null,
	QUIEN VARCHAR(50) null,
	CUANDO datetime null,
	EQUIPO varchar(50),
	Enviado int default 0,	
	[Version] bigint not null default 1
)